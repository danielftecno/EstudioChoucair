package co.com.choucair.proyectobase.tasks;

import co.com.choucair.proyectobase.userinterfaces.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class Traducir implements Task {

    private String palabraATraducir;

    public Traducir(String palabraATraducir) {
        this.palabraATraducir = palabraATraducir;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Click.on(HomePage.BOTON_ESPAÑOL));
        actor.attemptsTo(Enter.theValue(palabraATraducir).into(HomePage.PALABRA_A_TRADUCIR));
        actor.attemptsTo(Click.on(HomePage.BOTON_INGLES));
    }
    public static Performable palabra(String palabraATraducir) {
    return Tasks.instrumented(Traducir.class, palabraATraducir);
    }

}
