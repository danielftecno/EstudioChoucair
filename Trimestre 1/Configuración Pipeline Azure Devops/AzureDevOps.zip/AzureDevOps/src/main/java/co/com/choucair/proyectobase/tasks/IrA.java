package co.com.choucair.proyectobase.tasks;

import co.com.choucair.proyectobase.userinterfaces.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Open;

public class IrA implements Task {


    private HomePage homePage;



    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Open.browserOn(homePage));
    }


    public static IrA elTraductor(){
        return Tasks.instrumented(IrA.class);
    }
}
