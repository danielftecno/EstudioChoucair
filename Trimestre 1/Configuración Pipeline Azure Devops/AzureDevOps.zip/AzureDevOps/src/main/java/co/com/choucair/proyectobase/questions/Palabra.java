package co.com.choucair.proyectobase.questions;

import co.com.choucair.proyectobase.userinterfaces.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;


public class Palabra implements Question<String> {

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(HomePage.PALABRA_TRADUCIDA).viewedBy(actor).asString();
    }
    public static Palabra traducida() {
        return new Palabra();
    }
}
