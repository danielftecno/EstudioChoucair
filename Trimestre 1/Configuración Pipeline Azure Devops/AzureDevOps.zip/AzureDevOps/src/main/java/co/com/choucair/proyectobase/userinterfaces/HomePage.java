package co.com.choucair.proyectobase.userinterfaces;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import org.openqa.selenium.By;


@DefaultUrl("https://translate.google.com.co/?hl=es&tab=wT1")
public class HomePage extends PageObject {

    public static final Target BOTON_ESPAÑOL = Target.the("boton español").located(By.xpath("(//*[@id=\"sugg-item-es\"])[1]"));
    public static final Target PALABRA_A_TRADUCIR = Target.the("palabra a traducir").located(By.xpath("//textarea[@id='source']"));
    public static final Target BOTON_INGLES = Target.the("boton ingles").located(By.xpath("(//*[@id=\"sugg-item-en\"])[2]"));
    public static final Target PALABRA_TRADUCIDA = Target.the("palabra traducida").located(By.xpath("//span[@class='tlid-translation translation']/span"));

}
