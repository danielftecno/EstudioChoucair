package co.com.choucair.proyectobase.stepdefinitions;

import co.com.choucair.proyectobase.questions.Palabra;
import co.com.choucair.proyectobase.tasks.IrA;
import co.com.choucair.proyectobase.tasks.Traducir;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import cucumber.api.java.Before;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Managed;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebDriver;

import java.util.regex.Matcher;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class TraducirPalabraStepDefinitions {

    @Managed(driver = "chrome")
    private WebDriver driver;
    private static Actor usuario = Actor.named("Daniel");

    @Before
    public void iniciarNavegador(){
        usuario.can(BrowseTheWeb.with(driver));
    }


    @Dado("^que el usuario ingresa al traductor de google$")
    public void queElUsuarioIngresaAlTraductorDeGoogle() {
        System.out.println("DADO");
       usuario.wasAbleTo(IrA.elTraductor());
    }


    @Cuando("^traduce la palabra \"([^\"]*)\" de español a ingles$")
    public void traduceLaPalabraDeEspañolAIngles(String palabraATraducir) {
        System.out.println("CUANDO: "+palabraATraducir);
        usuario.attemptsTo(Traducir.palabra(palabraATraducir));
    }

    @Entonces("^se muestra el como resultado la palabra \"([^\"]*)\"$")
    public void seMuestraElComoResultadoLaPalabra(String palabraTraducida) {
        usuario.should(GivenWhenThen.seeThat(Palabra.traducida(), Matchers.equalTo(palabraTraducida)));
        System.out.println("ENTONCES: "+palabraTraducida);
    }
}
